"use client"

import type React from "react"

import { motion } from "framer-motion"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"

export default function ContactForm() {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    message: "",
  })
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [success, setSuccess] = useState(false)

  const validateForm = () => {
    const newErrors: Record<string, string> = {}

    if (formData.name.length < 2) {
      newErrors.name = "Ime mora imati najmanje 2 karaktera."
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(formData.email)) {
      newErrors.email = "Molimo unesite validnu email adresu."
    }

    if (formData.phone.length < 8) {
      newErrors.phone = "Broj telefona mora imati najmanje 8 cifara."
    }

    if (formData.message.length < 10) {
      newErrors.message = "Poruka mora imati najmanje 10 karaktera."
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateForm()) return

    setIsSubmitting(true)

    try {
      // Try Formspree first
      const formDataToSend = new FormData()
      formDataToSend.append("name", formData.name)
      formDataToSend.append("email", formData.email)
      formDataToSend.append("phone", formData.phone)
      formDataToSend.append("message", formData.message)
      formDataToSend.append("_replyto", formData.email)
      formDataToSend.append("_subject", `Nova poruka od ${formData.name} - AI Web VXS Design`)

      const response = await fetch("https://formspree.io/f/xdkogkva", {
        method: "POST",
        body: formDataToSend,
        headers: {
          Accept: "application/json",
        },
      })

      if (response.ok) {
        setSuccess(true)
        setFormData({ name: "", email: "", phone: "", message: "" })
      } else {
        throw new Error("Formspree failed")
      }
    } catch (error) {
      // Fallback to mailto
      const mailtoLink = `mailto:vxssclothing@gmail.com?subject=${encodeURIComponent(`Nova poruka od ${formData.name}`)}&body=${encodeURIComponent(`Ime: ${formData.name}\nEmail: ${formData.email}\nTelefon: ${formData.phone}\n\nPoruka:\n${formData.message}`)}`
      window.open(mailtoLink, "_blank")
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: "" }))
    }
  }

  return (
    <section className="relative overflow-hidden bg-black py-20">
      <div className="container relative z-10 mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="mx-auto max-w-2xl text-center"
        >
          <h1
            className="mb-4 text-4xl md:text-6xl font-bold tracking-tighter"
            style={{
              fontFamily: "Orbitron, monospace",
              background: "linear-gradient(45deg, #4dd0e1, #9c27b0)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              backgroundClip: "text",
            }}
          >
            Kontakt
          </h1>
          <p className="mb-8 text-gray-400 text-lg" style={{ fontFamily: "Rajdhani, sans-serif" }}>
            Zainteresovani za saradnju? Hajde da kreiramo nešto neverovatno zajedno.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          viewport={{ once: true }}
          className="mx-auto max-w-md"
        >
          {success && (
            <div className="mb-6 p-4 bg-green-900/20 border border-green-500 rounded-lg">
              <p className="text-green-400 text-center">Poruka poslata! Kontaktiraćemo vas uskoro.</p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-cyan-400 text-sm font-medium mb-2">Ime i prezime</label>
              <Input
                type="text"
                placeholder="Vaše ime i prezime"
                value={formData.name}
                onChange={(e) => handleInputChange("name", e.target.value)}
                className="bg-zinc-900 border-zinc-700 text-white placeholder:text-gray-500"
              />
              {errors.name && <p className="text-red-400 text-sm mt-1">{errors.name}</p>}
            </div>

            <div>
              <label className="block text-cyan-400 text-sm font-medium mb-2">Email</label>
              <Input
                type="email"
                placeholder="vas@email.com"
                value={formData.email}
                onChange={(e) => handleInputChange("email", e.target.value)}
                className="bg-zinc-900 border-zinc-700 text-white placeholder:text-gray-500"
              />
              {errors.email && <p className="text-red-400 text-sm mt-1">{errors.email}</p>}
            </div>

            <div>
              <label className="block text-cyan-400 text-sm font-medium mb-2">Broj telefona</label>
              <Input
                type="tel"
                placeholder="063/123-456"
                value={formData.phone}
                onChange={(e) => handleInputChange("phone", e.target.value)}
                className="bg-zinc-900 border-zinc-700 text-white placeholder:text-gray-500"
              />
              {errors.phone && <p className="text-red-400 text-sm mt-1">{errors.phone}</p>}
            </div>

            <div>
              <label className="block text-cyan-400 text-sm font-medium mb-2">Poruka</label>
              <Textarea
                placeholder="Opišite vaš projekat..."
                value={formData.message}
                onChange={(e) => handleInputChange("message", e.target.value)}
                className="min-h-[120px] bg-zinc-900 border-zinc-700 text-white placeholder:text-gray-500"
              />
              {errors.message && <p className="text-red-400 text-sm mt-1">{errors.message}</p>}
            </div>

            <Button
              type="submit"
              className="w-full bg-cyan-400 hover:bg-cyan-500 text-black font-semibold"
              disabled={isSubmitting}
            >
              {isSubmitting ? "Šalje se..." : "Pošalji poruku"}
            </Button>
          </form>

          <div className="mt-8 space-y-4">
            <div className="p-4 bg-zinc-900 rounded-lg border border-zinc-700">
              <h3 className="text-cyan-400 font-semibold mb-2">Direktan kontakt:</h3>
              <a
                href="mailto:vxssclothing@gmail.com"
                className="text-cyan-400 hover:text-cyan-300 transition-colors block mb-2"
              >
                📧 vxssclothing@gmail.com
              </a>
              <p className="text-gray-400 text-sm">Kliknite za direktno slanje emaila</p>
            </div>

            <Button
              onClick={() => {
                const mailtoLink = `mailto:vxssclothing@gmail.com?subject=${encodeURIComponent("Upit sa sajta AI Web VXS Design")}&body=${encodeURIComponent("Pozdrav,\n\nZainteresovan sam za vaše usluge.\n\nIme: \nTelefon: \n\nPoruka: \n\n")}`
                window.open(mailtoLink, "_blank")
              }}
              variant="outline"
              className="w-full border-cyan-400 text-cyan-400 hover:bg-cyan-400 hover:text-black"
            >
              📧 Otvori email klijent
            </Button>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
