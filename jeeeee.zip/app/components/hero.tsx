"use client"

import { useEffect, useRef } from "react"
import { motion } from "framer-motion"

export default function Hero() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const fireCanvasRef = useRef<HTMLCanvasElement>(null)
  const textRef = useRef<HTMLHeadingElement>(null)
  const audioRef = useRef<HTMLAudioElement | null>(null)

  // Electric sound effect
  useEffect(() => {
    // Create electric buzzing sound
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)()

    const createElectricSound = () => {
      const oscillator = audioContext.createOscillator()
      const gainNode = audioContext.createGain()
      const filter = audioContext.createBiquadFilter()

      oscillator.connect(filter)
      filter.connect(gainNode)
      gainNode.connect(audioContext.destination)

      oscillator.type = "sawtooth"
      oscillator.frequency.setValueAtTime(60, audioContext.currentTime)
      oscillator.frequency.exponentialRampToValueAtTime(120, audioContext.currentTime + 0.1)
      oscillator.frequency.exponentialRampToValueAtTime(40, audioContext.currentTime + 0.3)

      filter.type = "highpass"
      filter.frequency.setValueAtTime(100, audioContext.currentTime)

      gainNode.gain.setValueAtTime(0, audioContext.currentTime)
      gainNode.gain.linearRampToValueAtTime(0.02, audioContext.currentTime + 0.01)
      gainNode.gain.exponentialRampToValueAtTime(0.001, audioContext.currentTime + 0.3)

      oscillator.start(audioContext.currentTime)
      oscillator.stop(audioContext.currentTime + 0.3)
    }

    const playElectricSound = () => {
      if (audioContext.state === "suspended") {
        audioContext.resume()
      }
      createElectricSound()
    }

    // Play electric sound every 3-5 seconds
    const soundInterval = setInterval(
      () => {
        if (Math.random() > 0.3) {
          // 70% chance to play
          playElectricSound()
        }
      },
      Math.random() * 2000 + 3000,
    )

    // Initial click to enable audio
    const enableAudio = () => {
      audioContext.resume()
      playElectricSound()
      document.removeEventListener("click", enableAudio)
    }
    document.addEventListener("click", enableAudio)

    return () => {
      clearInterval(soundInterval)
      document.removeEventListener("click", enableAudio)
      audioContext.close()
    }
  }, [])

  useEffect(() => {
    if (!canvasRef.current) return

    const canvas = canvasRef.current
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    canvas.width = window.innerWidth
    canvas.height = window.innerHeight

    const particles: any[] = []
    const particleCount = 100

    class Particle {
      x: number
      y: number
      size: number
      speedX: number
      speedY: number
      color: string
      opacity: number

      constructor() {
        this.x = Math.random() * canvas.width
        this.y = Math.random() * canvas.height
        this.size = Math.random() * 2 + 0.5
        this.speedX = Math.random() * 2 - 1
        this.speedY = Math.random() * 2 - 1
        this.color = Math.random() > 0.5 ? "#4dd0e1" : "#9c27b0"
        this.opacity = Math.random() * 0.5 + 0.2
      }

      update() {
        this.x += this.speedX
        this.y += this.speedY

        if (this.x > canvas.width) this.x = 0
        if (this.x < 0) this.x = canvas.width
        if (this.y > canvas.height) this.y = 0
        if (this.y < 0) this.y = canvas.height
      }

      draw() {
        if (!ctx) return
        ctx.fillStyle =
          this.color +
          Math.floor(this.opacity * 255)
            .toString(16)
            .padStart(2, "0")
        ctx.beginPath()
        ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2)
        ctx.fill()
      }
    }

    for (let i = 0; i < particleCount; i++) {
      particles.push(new Particle())
    }

    function animate() {
      if (!ctx) return
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      for (const particle of particles) {
        particle.update()
        particle.draw()
      }

      requestAnimationFrame(animate)
    }

    animate()

    const handleResize = () => {
      if (!canvasRef.current) return
      canvasRef.current.width = window.innerWidth
      canvasRef.current.height = window.innerHeight
    }

    window.addEventListener("resize", handleResize)
    return () => window.removeEventListener("resize", handleResize)
  }, [])

  // Fire animation
  useEffect(() => {
    if (!fireCanvasRef.current) return

    const canvas = fireCanvasRef.current
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    canvas.width = window.innerWidth
    canvas.height = window.innerHeight

    const fireParticles: any[] = []
    const fireParticleCount = 150

    class FireParticle {
      x: number
      y: number
      size: number
      speedX: number
      speedY: number
      life: number
      maxLife: number
      color: string

      constructor() {
        this.x = Math.random() * canvas.width
        this.y = canvas.height * 0.6 + Math.random() * 20
        this.size = Math.random() * 3 + 1
        this.speedX = (Math.random() - 0.5) * 1.5
        this.speedY = -Math.random() * 2.5 - 1
        this.life = 0
        this.maxLife = Math.random() * 50 + 30
        this.color = this.getFireColor()
      }

      getFireColor() {
        const colors = ["#ff4500", "#ff6500", "#ff8500", "#ffa500", "#ffff00", "#ff0000"]
        return colors[Math.floor(Math.random() * colors.length)]
      }

      update() {
        this.x += this.speedX
        this.y += this.speedY
        this.life++

        if (this.life > this.maxLife * 0.8) {
          this.size *= 0.98
        }

        if (this.life >= this.maxLife || this.size < 0.1) {
          this.x = Math.random() * canvas.width
          this.y = canvas.height * 0.6 + Math.random() * 20
          this.size = Math.random() * 3 + 1
          this.speedX = (Math.random() - 0.5) * 1.5
          this.speedY = -Math.random() * 2.5 - 1
          this.life = 0
          this.maxLife = Math.random() * 50 + 30
          this.color = this.getFireColor()
        }
      }

      draw() {
        if (!ctx) return
        const opacity = (1 - this.life / this.maxLife) * 0.8
        ctx.globalAlpha = opacity
        ctx.fillStyle = this.color
        ctx.shadowColor = this.color
        ctx.shadowBlur = 8
        ctx.beginPath()
        ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2)
        ctx.fill()
        ctx.shadowBlur = 0
        ctx.globalAlpha = 1
      }
    }

    for (let i = 0; i < fireParticleCount; i++) {
      fireParticles.push(new FireParticle())
    }

    function animateFire() {
      if (!ctx) return
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      for (const particle of fireParticles) {
        particle.update()
        particle.draw()
      }

      requestAnimationFrame(animateFire)
    }

    animateFire()

    const handleResize = () => {
      if (!fireCanvasRef.current) return
      fireCanvasRef.current.width = window.innerWidth
      fireCanvasRef.current.height = window.innerHeight
    }

    window.addEventListener("resize", handleResize)
    return () => window.removeEventListener("resize", handleResize)
  }, [])

  return (
    <div className="relative h-screen w-full overflow-hidden">
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full bg-black" />
      <canvas ref={fireCanvasRef} className="absolute inset-0 h-full w-full" />
      <div className="relative z-10 flex h-full flex-col items-center justify-center px-4 text-center">
        <motion.h1
          ref={textRef}
          className="mb-6 text-6xl font-bold tracking-wider sm:text-7xl lg:text-8xl electric-text"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          style={{
            fontFamily: "Orbitron, monospace",
            background: "linear-gradient(45deg, #4dd0e1, #9c27b0, #64b5f6, #4dd0e1)",
            backgroundSize: "400% 400%",
            WebkitBackgroundClip: "text",
            WebkitTextFillColor: "transparent",
            backgroundClip: "text",
            animation: "electric-flow 4s ease-in-out infinite, gradient-shift 5s ease-in-out infinite",
            textShadow: "0 0 8px rgba(77, 208, 225, 0.6), 0 0 12px rgba(77, 208, 225, 0.4)",
            filter: "drop-shadow(0 0 6px rgba(156, 39, 176, 0.5))",
            fontWeight: "700",
          }}
        >
          AI WEB VXS DESIGN
        </motion.h1>

        {/* Fire line under text */}
        <div className="fire-line mb-4"></div>

        <motion.p
          className="max-w-[600px] text-lg text-gray-300 sm:text-xl"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          style={{
            fontFamily: "Rajdhani, sans-serif",
            color: "#4dd0e1",
            textShadow: "0 0 4px rgba(77, 208, 225, 0.5)",
            fontWeight: "500",
          }}
        >
          AI-Powered Web & Visual Experience Solutions
        </motion.p>
      </div>

      <style jsx>{`
        @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Rajdhani:wght@300;400;500;600;700&display=swap');
        
        @keyframes electric-flow {
          0%, 100% {
            text-shadow: 
              0 0 5px rgba(77, 208, 225, 0.8),
              0 0 10px rgba(77, 208, 225, 0.6),
              0 0 15px rgba(77, 208, 225, 0.4),
              0 0 20px rgba(77, 208, 225, 0.2);
          }
          25% {
            text-shadow: 
              0 0 5px rgba(156, 39, 176, 0.8),
              0 0 10px rgba(156, 39, 176, 0.6),
              0 0 15px rgba(156, 39, 176, 0.4),
              0 0 20px rgba(156, 39, 176, 0.2);
          }
          50% {
            text-shadow: 
              0 0 5px rgba(100, 181, 246, 0.8),
              0 0 10px rgba(100, 181, 246, 0.6),
              0 0 15px rgba(100, 181, 246, 0.4),
              0 0 20px rgba(100, 181, 246, 0.2);
          }
          75% {
            text-shadow: 
              0 0 5px rgba(77, 208, 225, 0.8),
              0 0 10px rgba(77, 208, 225, 0.6),
              0 0 15px rgba(77, 208, 225, 0.4),
              0 0 20px rgba(77, 208, 225, 0.2);
          }
        }
        
        @keyframes gradient-shift {
          0% {
            background-position: 0% 50%;
          }
          50% {
            background-position: 100% 50%;
          }
          100% {
            background-position: 0% 50%;
          }
        }
        
        .electric-text {
          position: relative;
        }
        
        .electric-text::before {
          content: '';
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: linear-gradient(90deg, 
            transparent, 
            rgba(77, 208, 225, 0.3), 
            rgba(156, 39, 176, 0.3), 
            rgba(77, 208, 225, 0.3), 
            transparent
          );
          animation: lightning-sweep 3s linear infinite;
          pointer-events: none;
        }
        
        .electric-text::after {
          content: '';
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: linear-gradient(45deg, 
            transparent, 
            rgba(77, 208, 225, 0.1), 
            transparent, 
            rgba(156, 39, 176, 0.1), 
            transparent
          );
          animation: electric-zap 0.1s linear infinite;
          pointer-events: none;
          opacity: 0;
        }
        
        @keyframes lightning-sweep {
          0% {
            transform: translateX(-100%);
          }
          100% {
            transform: translateX(100%);
          }
        }
        
        @keyframes electric-zap {
          0%, 90% {
            opacity: 0;
          }
          95% {
            opacity: 1;
          }
          100% {
            opacity: 0;
          }
        }
        
        .fire-line {
          width: 70%;
          height: 3px;
          background: linear-gradient(90deg, 
            transparent, 
            #ff4500, 
            #ff6500, 
            #ff8500, 
            #ffa500, 
            #ffff00, 
            #ffa500, 
            #ff8500, 
            #ff6500, 
            #ff4500, 
            transparent
          );
          background-size: 200% 100%;
          animation: fire-flow 2.5s linear infinite;
          border-radius: 2px;
          box-shadow: 
            0 0 6px #ff4500,
            0 0 12px #ff6500;
        }
        
        @keyframes fire-flow {
          0% {
            background-position: -200% 0;
          }
          100% {
            background-position: 200% 0;
          }
        }
      `}</style>
    </div>
  )
}
