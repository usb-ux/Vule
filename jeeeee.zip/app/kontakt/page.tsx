"use client"

import type React from "react"

import Navigation from "../components/navigation"
import { useState } from "react"

export default function KontaktPage() {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    message: "",
  })
  const [success, setSuccess] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simple mailto fallback
    const mailtoLink = `mailto:vxssclothing@gmail.com?subject=${encodeURIComponent(`Nova poruka od ${formData.name}`)}&body=${encodeURIComponent(`Ime: ${formData.name}\nEmail: ${formData.email}\nTelefon: ${formData.phone}\n\nPoruka:\n${formData.message}`)}`

    window.open(mailtoLink, "_blank")
    setSuccess(true)
    setFormData({ name: "", email: "", phone: "", message: "" })
    setIsSubmitting(false)
  }

  return (
    <main className="min-h-screen bg-black text-white">
      <Navigation />
      <div className="pt-20 pb-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 electric-text">Kontakt</h1>
            <p className="text-xl text-gray-400 max-w-2xl mx-auto" style={{ fontFamily: "Rajdhani, sans-serif" }}>
              Zainteresovani za saradnju? Hajde da kreiramo nešto neverovatno zajedno.
            </p>
          </div>

          <div className="max-w-md mx-auto">
            {success && (
              <div className="mb-6 p-4 bg-green-900/20 border border-green-500 rounded-lg">
                <p className="text-green-400 text-center">Email klijent je otvoren! Pošaljite poruku.</p>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-cyan-400 text-sm font-medium mb-2">Ime i prezime</label>
                <input
                  type="text"
                  placeholder="Vaše ime i prezime"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full p-3 bg-zinc-900 border border-zinc-700 text-white placeholder:text-gray-500 rounded"
                  required
                />
              </div>

              <div>
                <label className="block text-cyan-400 text-sm font-medium mb-2">Email</label>
                <input
                  type="email"
                  placeholder="vas@email.com"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full p-3 bg-zinc-900 border border-zinc-700 text-white placeholder:text-gray-500 rounded"
                  required
                />
              </div>

              <div>
                <label className="block text-cyan-400 text-sm font-medium mb-2">Broj telefona</label>
                <input
                  type="tel"
                  placeholder="063/123-456"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full p-3 bg-zinc-900 border border-zinc-700 text-white placeholder:text-gray-500 rounded"
                  required
                />
              </div>

              <div>
                <label className="block text-cyan-400 text-sm font-medium mb-2">Poruka</label>
                <textarea
                  placeholder="Opišite vaš projekat..."
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  className="w-full p-3 bg-zinc-900 border border-zinc-700 text-white placeholder:text-gray-500 rounded min-h-[120px]"
                  required
                />
              </div>

              <button
                type="submit"
                className="w-full bg-cyan-400 hover:bg-cyan-500 text-black font-semibold py-3 rounded transition-colors"
                disabled={isSubmitting}
              >
                {isSubmitting ? "Otvara email..." : "Pošalji poruku"}
              </button>
            </form>

            <div className="mt-8 space-y-4">
              <div className="p-4 bg-zinc-900 rounded-lg border border-zinc-700">
                <h3 className="text-cyan-400 font-semibold mb-2">Direktan kontakt:</h3>
                <a
                  href="mailto:vxssclothing@gmail.com"
                  className="text-cyan-400 hover:text-cyan-300 transition-colors block mb-2"
                >
                  📧 vxssclothing@gmail.com
                </a>
                <p className="text-gray-400 text-sm">Kliknite za direktno slanje emaila</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  )
}
