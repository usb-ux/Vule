"use client"

import Navigation from "../components/navigation"

export default function CenovnikPage() {
  const packages = [
    {
      name: "Osnovni",
      price: "15.000",
      description: "Idealno za mala preduzeća i startove",
      features: [
        "Responzivni dizajn",
        "Do 5 stranica",
        "Kontakt forma",
        "Osnovna SEO optimizacija",
        "1 mesec besplatne izmene",
        "Hosting za 6 meseci",
      ],
      popular: false,
    },
    {
      name: "Profesionalni",
      price: "35.000",
      description: "Za ozbiljne biznise koji žele da se istaknu",
      features: [
        "Sve iz osnovnog paketa",
        "Do 10 stranica",
        "AI chatbot integracija",
        "Napredna SEO optimizacija",
        "Google Analytics",
        "3 meseca besplatne izmene",
        "Hosting za 1 godinu",
        "Brza podrška",
      ],
      popular: true,
    },
    {
      name: "Premium",
      price: "65.000",
      description: "Kompletno rešenje za velike kompanije",
      features: [
        "Sve iz profesionalnog paketa",
        "Neograničen broj stranica",
        "E-commerce funkcionalnost",
        "Napredni AI alati",
        "Personalizovani dizajn",
        "6 meseci besplatne izmene",
        "Hosting za 2 godine",
        "24/7 podrška",
        "Mesečni izveštaji",
      ],
      popular: false,
    },
  ]

  return (
    <main className="min-h-screen bg-black text-white">
      <Navigation />
      <div className="pt-20 pb-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 electric-text">Cenovnik</h1>
            <p className="text-xl text-gray-400 max-w-2xl mx-auto" style={{ fontFamily: "Rajdhani, sans-serif" }}>
              Izaberite paket koji najbolje odgovara vašim potrebama. Sve cene su u dinarima.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {packages.map((pkg, index) => (
              <div
                key={pkg.name}
                className={`relative bg-zinc-900 border border-zinc-800 rounded-lg p-6 ${pkg.popular ? "border-cyan-400 scale-105" : ""}`}
              >
                {pkg.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <span className="bg-cyan-400 text-black px-4 py-1 rounded-full text-sm font-semibold">
                      Najpopularniji
                    </span>
                  </div>
                )}

                <div className="text-center pb-8">
                  <h2 className="text-2xl font-bold text-white mb-2" style={{ fontFamily: "Orbitron, monospace" }}>
                    {pkg.name}
                  </h2>
                  <div className="mb-4">
                    <span className="text-4xl font-bold text-cyan-400">{pkg.price}</span>
                    <span className="text-gray-400 ml-2">RSD</span>
                  </div>
                  <p className="text-gray-400 text-sm">{pkg.description}</p>
                </div>

                <ul className="space-y-3 mb-8">
                  {pkg.features.map((feature, i) => (
                    <li key={i} className="flex items-center text-sm">
                      <span className="text-cyan-400 mr-3">✓</span>
                      <span className="text-gray-300">{feature}</span>
                    </li>
                  ))}
                </ul>

                <button
                  className={`w-full py-2 px-4 rounded font-semibold transition-colors ${
                    pkg.popular
                      ? "bg-cyan-400 hover:bg-cyan-500 text-black"
                      : "bg-zinc-800 hover:bg-zinc-700 text-white"
                  }`}
                  onClick={() => (window.location.href = "/kontakt")}
                >
                  Izaberi paket
                </button>
              </div>
            ))}
          </div>

          <div className="text-center mt-16">
            <p className="text-gray-400 mb-4">Potrebno vam je nešto specifično?</p>
            <button
              className="border border-cyan-400 text-cyan-400 hover:bg-cyan-400 hover:text-black bg-transparent py-2 px-6 rounded transition-colors"
              onClick={() => (window.location.href = "/kontakt")}
            >
              Kontaktirajte nas za custom ponudu
            </button>
          </div>
        </div>
      </div>
    </main>
  )
}
