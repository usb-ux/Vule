import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { name, email, phone, message } = body

    // Using EmailJS or similar service to send emails
    // For now, we'll use a simple fetch to a email service

    const emailContent = `
Novo kontakt sa sajta AI Web VXS Design

Ime: ${name}
Email: ${email}
Telefon: ${phone}

Poruka:
${message}

---
Poslano sa sajta: ${new Date().toLocaleString("sr-RS")}
    `

    // Using Formspree (free email service)
    const response = await fetch("https://formspree.io/f/xdkogkva", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        email: email,
        name: name,
        phone: phone,
        message: emailContent,
        _replyto: email,
        _subject: `Nova poruka od ${name} - AI Web VXS Design`,
      }),
    })

    if (response.ok) {
      return NextResponse.json({ success: true })
    } else {
      throw new Error("Failed to send email")
    }
  } catch (error) {
    console.error("Error processing contact form:", error)
    return NextResponse.json({ error: "Failed to send message" }, { status: 500 })
  }
}
